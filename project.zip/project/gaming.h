#ifndef GAMING_H
#define GAMING_H

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <limits>
using namespace std;

// ─────────────────────────────────────────────
//  Helper: sirf valid int input lo
//  letter ya kuch aur likha to dubara maango
// ─────────────────────────────────────────────
int getInt() {
    int val;
    while (!(cin >> val)) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Only enter numbers: ";
    }
    return val;
}

// ─────────────────────────────────────────────
//  Helper: sirf y ya n lo, baaki sab reject
// ─────────────────────────────────────────────
char getYN() {
    char ch;
    while (true) {
        cin >> ch;
        ch = tolower(ch);
        if (ch == 'y' || ch == 'n') return ch;
        cout << "Press 'y' or 'n' only: ";
    }
}

// ─────────────────────────────────────────────
//  Base Class demonstrating Abstraction 
// ─────────────────────────────────────────────
class BaseGame {
public:
    virtual int startGame() = 0; // Pure virtual function (Abstraction)
    virtual ~BaseGame() {}       // Virtual Destructor
};

// ─────────────────────────────────────────────
//  1. Number Guess Game  (Inherits from BaseGame)
// ─────────────────────────────────────────────
class GuessNumberGame : public BaseGame {
private:
    int score;

public:
    GuessNumberGame() : score(0) { srand(time(0)); }

    int startGame() {
        char choice;
        do {
            int secret = rand() % 100 + 1;

            cout << "\n================================" << endl;
            cout << "    Number Guess Game (1-100)    " << endl;
            cout << "================================" << endl;
            cout << "Look at this number: " << secret << endl;
            cout << "Enter the NEXT number: ";

            int guess = getInt();

            if (guess == secret + 1) {
                cout << "Correct NEXT number!" << endl;
                score++;
            }
            else {
                cout << "Wrong! The correct number was: " << secret + 1 << endl;
                if (score > 0) score--;
            }

            cout << "Score: " << score << endl;
            cout << "Do you want to play again? (y/n): ";
            choice = getYN();

        } while (choice == 'y');

        return score;
    }
};

// ─────────────────────────────────────────────
//  2. Picture Quiz  (Inherits from BaseGame)
// ─────────────────────────────────────────────
class PictureQuizGame : public BaseGame {
private:
    struct Question {
        string hint;
        string options[4];
        int correctIndex;
    };

    static const int TOTAL = 10;
    Question questions[TOTAL];
    int score;

public:
    PictureQuizGame() : score(0) {
        srand(time(0));

        questions[0] = { "Apple",     {"Banana","Apple","Orange","Mango"},    1 };
        questions[1] = { "Cat",       {"Dog","Lion","Cat","Tiger"},           2 };
        questions[2] = { "Car",       {"Bike","Bus","Car","Truck"},           2 };
        questions[3] = { "Bird",      {"Fish","Dog","Cat","Bird"},            3 };
        questions[4] = { "Sun",       {"Moon","Star","Sun","Cloud"},          2 };
        questions[5] = { "Tree",      {"Flower","Tree","Grass","Rock"},       1 };
        questions[6] = { "Book",      {"Pen","Book","Eraser","Ruler"},        1 };
        questions[7] = { "Fish",      {"Fish","Duck","Crab","Whale"},         0 };
        questions[8] = { "Ball",      {"Cube","Cone","Ball","Pyramid"},       2 };
        questions[9] = { "House",     {"Hotel","Castle","Hut","House"},       3 };
    }

    int startGame() {
        char choice;
        do {
            int q = rand() % TOTAL;

            cout << "\n================================" << endl;
            cout << "          Picture Quiz          " << endl;
            cout << "================================" << endl;
            cout << "Find: " << questions[q].hint << endl;

            for (int i = 0; i < 4; i++)
                cout << i + 1 << ". " << questions[q].options[i] << endl;

            cout << "Answer (1-4): ";
            int ans = getInt();

            if (ans < 1 || ans > 4) {
                cout << "Please enter a number between 1 and 4!" << endl;
            }
            else if (ans == questions[q].correctIndex + 1) {
                cout << "Correct!" << endl;
                score++;
            }
            else {
                cout << "Wrong! Correct answer was: "
                    << questions[q].options[questions[q].correctIndex] << endl;
                if (score > 0) score--;
            }

            cout << "Score: " << score << endl;
            cout << "Play again? (y/n): ";
            choice = getYN();

        } while (choice == 'y');

        return score;
    }
};

// ─────────────────────────────────────────────
//  3. Missing Letter Puzzle (Inherits BaseGame)
// ─────────────────────────────────────────────
class MissingLetterPuzzle : public BaseGame {
private:
    struct Question {
        string word;
        string options[4];
        int correctIndex;
    };

    static const int TOTAL = 10;
    Question questions[TOTAL];
    int score;

public:
    MissingLetterPuzzle() : score(0) {
        srand(time(0));

        questions[0] = { "C_T",  {"A","O","E","U"}, 0 };
        questions[1] = { "D_G",  {"A","O","I","E"}, 1 };
        questions[2] = { "B_LL", {"E","I","A","O"}, 0 };
        questions[3] = { "F_SH", {"A","I","O","E"}, 1 };
        questions[4] = { "S_N",  {"O","A","U","I"}, 0 };
        questions[5] = { "H_T",  {"A","E","I","O"}, 0 };
        questions[6] = { "B_G",  {"A","U","E","I"}, 1 };
        questions[7] = { "C_P",  {"U","O","A","E"}, 0 };
        questions[8] = { "L_G",  {"E","I","A","O"}, 2 };
        questions[9] = { "P_G",  {"I","E","A","U"}, 0 };
    }

    int startGame() {
        char choice;
        do {
            int i = rand() % TOTAL;

            cout << "\n================================" << endl;
            cout << "       Missing Letter Game      " << endl;
            cout << "================================" << endl;
            cout << "Complete this word: " << questions[i].word << endl;

            for (int j = 0; j < 4; j++)
                cout << j + 1 << ". " << questions[i].options[j] << endl;

            cout << "Answer (1-4): ";
            int ans = getInt();

            if (ans < 1 || ans > 4) {
                cout << "Please enter a number between 1 and 4!" << endl;
            }
            else if (ans == questions[i].correctIndex + 1) {
                cout << "Correct!" << endl;
                score++;
            }
            else {
                cout << "Wrong! The correct letter was: "
                    << questions[i].options[questions[i].correctIndex] << endl;
                if (score > 0) score--;
            }

            cout << "Score: " << score << endl;
            cout << "Play again? (y/n): ";
            choice = getYN();

        } while (choice == 'y');

        return score;
    }
};

// ─────────────────────────────────────────────
//  4. Color Guess Game (Inherits from BaseGame)
// ─────────────────────────────────────────────
class ColorGuessGame : public BaseGame {
private:
    struct Question {
        string object;
        string options[4];
        int correctIndex;
    };

    static const int TOTAL = 12;
    Question questions[TOTAL];
    int score;

public:
    ColorGuessGame() : score(0) {
        srand(time(0));

        questions[0] = { "Apple",       {"Blue","Green","Red","Yellow"},    2 };
        questions[1] = { "Sun",         {"Yellow","Pink","Black","White"},  0 };
        questions[2] = { "Grass",       {"Orange","Green","Purple","Red"},  1 };
        questions[3] = { "Cloud",       {"White","Brown","Green","Blue"},   0 };
        questions[4] = { "Sky",         {"Green","Blue","Red","Yellow"},    1 };
        questions[5] = { "Banana",      {"Red","Orange","Yellow","Purple"}, 2 };
        questions[6] = { "Tomato",      {"Red","Blue","Green","White"},     0 };
        questions[7] = { "Carrot",      {"Purple","Orange","Green","Pink"}, 1 };
        questions[8] = { "Elephant",    {"Black","Gray","Brown","White"},   1 };
        questions[9] = { "Peacock",     {"Red","Yellow","Blue","Green"},    2 };
        questions[10] = { "Milk",        {"Yellow","White","Blue","Pink"},   1 };
        questions[11] = { "Coal",        {"Brown","Gray","Black","Red"},     2 };
    }

    int startGame() {
        char choice;
        do {
            int i = rand() % TOTAL;

            cout << "\n================================" << endl;
            cout << "        Color Guess Game        " << endl;
            cout << "================================" << endl;
            cout << "Guess the color of: " << questions[i].object << endl;

            for (int j = 0; j < 4; j++)
                cout << j + 1 << ". " << questions[i].options[j] << endl;

            cout << "Answer (1-4): ";
            int ans = getInt();

            if (ans < 1 || ans > 4) {
                cout << "Please enter a number between 1 and 4!" << endl;
            }
            else if (ans == questions[i].correctIndex + 1) {
                cout << "Correct color!" << endl;
                score++;
            }
            else {
                cout << "Wrong! Correct color was: "
                    << questions[i].options[questions[i].correctIndex] << endl;
                if (score > 0) score--;
            }

            cout << "Score: " << score << endl;
            cout << "Play again? (y/n): ";
            choice = getYN();

        } while (choice == 'y');

        return score;
    }
};

// ─────────────────────────────────────────────
//  MAIN
// ─────────────────────────────────────────────
void runall() {
    int choice;
    int totalScore = 0;

    do {
        cout << "\n================================" << endl;
        cout << "          GAME MODULE           " << endl;
        cout << "================================" << endl;
        cout << "1. Number Guess (1-100)" << endl;
        cout << "2. Picture Quiz" << endl;
        cout << "3. Missing Letter" << endl;
        cout << "4. Color Guess" << endl;
        cout << "5. Exit" << endl;
        cout << "Choice: ";

        choice = getInt();

        BaseGame* activeGame = nullptr; // Polymorphic Pointer

        if (choice == 1)      activeGame = new GuessNumberGame();
        else if (choice == 2) activeGame = new PictureQuizGame();
        else if (choice == 3) activeGame = new MissingLetterPuzzle();
        else if (choice == 4) activeGame = new ColorGuessGame();
        else if (choice != 5) cout << "Please enter a number between 1 and 5!" << endl;

        // Executing polymorphism if an active game object exists
        if (activeGame) {
            totalScore += activeGame->startGame(); // Calls overriding function dynamically
            delete activeGame; // Clean Up memory
        }

    } while (choice != 5);

    cout << "\nFinal Score: " << totalScore << endl;
    cout << "Goodbye!" << endl;
}

#endif