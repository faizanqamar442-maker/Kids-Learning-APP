#include "ui.h"
#include <ctime>

int main() {
    srand(static_cast<unsigned int>(time(0)));
    
    SFMLApp app;
    app.run();
    
    return 0;
}
 