#ifndef LEARING_H
#define LEARING_H

// ================= MAC MODIFICATIONS =================
// The following block of headers replaces the Windows specific ones 
// but keeps the Windows headers commented out as requested.

// #define NOMINMAX
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
// #include <windows.h>
// #include <conio.h>
#include <ctime>
#include <limits>
#include "gaming.h"

// MAC SPECIFIC HEADERS FOR I/O and TIMING
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>

using namespace std;

// MAC SPECIFIC IMPLEMENTATION FOR kbhit AND getch
inline int _kbhit(void) {
    struct termios oldt, newt;
    int ch;
    int oldf;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);
    ch = getchar();
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);
    if(ch != EOF) {
        ungetc(ch, stdin);
        return 1;
    }
    return 0;
}

inline char _getch(void) {
    struct termios oldattr, newattr;
    int ch;
    tcgetattr(STDIN_FILENO, &oldattr);
    newattr = oldattr;
    newattr.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newattr);
    ch = getchar();
    tcsetattr(STDIN_FILENO, TCSANOW, &oldattr);
    return ch;
}
// =====================================================


// ================= HELPER =================
int safeInput(int minVal, int maxVal, string errorMsg) {
    int val;
    while (true) {
        if (cin >> val && val >= minVal && val <= maxVal) {
            cin.ignore(1000, '\n');
            return val;
        }
        cin.clear();
        cin.ignore(1000, '\n');
        cout << errorMsg;
    }
}

// ================= VOICE AGENT =================
class VoiceAgent {
public:
    // ADDED: A boolean flag 'printText'. It defaults to true so old code doesn't break.
    void speak(string text, bool printText = true) {
        if (printText) {
            cout << "Robot: " << text << endl;
        }

        // WINDOWS CODE COMMENTED
        // string command = "powershell -Command \"Add-Type -AssemblyName System.Speech; "
        //     "$speak = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
        //     "$speak.Speak(\\\"" + text + "\\\")\"";
        // system(command.c_str());

        // MAC CODE
        string command = "say \"[[volm 1.0]] [[pbas 90]] " + text + "\" &";
        system(command.c_str());
    }
};

// ================= USER CLASS =================
class User {
public:
    string name;
    int age;
    string password;

    User(string n = "", int a = 0, string p = "") {
        name = n;
        age = a;
        password = p;
    }
};

// ================= FILE MANAGER =================
class FileManager {
public:
    void registerUser() {
        string name, password;
        int age;

        cout << "\nEnter Name: ";    cin >> name;
        cout << "Enter Age: ";       cin >> age;
        cout << "Enter Password: ";  cin >> password;

        ofstream file("users.txt", ios::app);
        file << name << "," << age << "," << password << endl;
        file.close();

        cout << "Registration Successful!\n";
    }

    User loginUser() {
        string name, password;
        cout << "\nEnter Name: ";    cin >> name;
        cout << "Enter Password: ";  cin >> password;

        ifstream file("users.txt");
        string line;

        while (getline(file, line)) {
            size_t pos1 = line.find(',');
            size_t pos2 = line.find(',', pos1 + 1);

            if (pos1 == string::npos || pos2 == string::npos)
                continue;

            string n = line.substr(0, pos1);
            int    a = stoi(line.substr(pos1 + 1, pos2 - pos1 - 1));
            string p = line.substr(pos2 + 1);

            if (n == name && p == password) {
                cout << "Login Successful!\n";
                return User(n, a, p);
            }
        }

        cout << "Invalid Login!\n";
        return User("", 0, "");
    }

    void saveProgress(string username, string lessonType, int index) {
        vector<string> lines;
        bool found = false;

        ifstream fin("progress.txt");
        string line;
        while (getline(fin, line)) {
            size_t p1 = line.find(',');
            size_t p2 = line.find(',', p1 + 1);
            if (p1 == string::npos || p2 == string::npos) {
                lines.push_back(line);
                continue;
            }
            string uname = line.substr(0, p1);
            string ltype = line.substr(p1 + 1, p2 - p1 - 1);

            if (uname == username && ltype == lessonType) {
                lines.push_back(username + "," + lessonType + "," + to_string(index));
                found = true;
            }
            else {
                lines.push_back(line);
            }
        }
        fin.close();

        if (!found)
            lines.push_back(username + "," + lessonType + "," + to_string(index));

        ofstream fout("progress.txt");
        for (int i = 0; i < (int)lines.size(); i++)
            fout << lines[i] << endl;
        fout.close();
    }

    int loadProgress(string username, string lessonType) {
        ifstream fin("progress.txt");
        string line;
        while (getline(fin, line)) {
            size_t p1 = line.find(',');
            size_t p2 = line.find(',', p1 + 1);
            if (p1 == string::npos || p2 == string::npos) continue;

            string uname = line.substr(0, p1);
            string ltype = line.substr(p1 + 1, p2 - p1 - 1);
            int    idx = stoi(line.substr(p2 + 1));

            if (uname == username && ltype == lessonType)
                return idx;
        }
        return -1;
    }

    void resetProgress(string username) {
        string lessons[] = { "alpha", "number", "fruit", "animal", "gamescore" };
        for (int i = 0; i < 5; i++)
            saveProgress(username, lessons[i], 0);
    }
};

// ================= ROBOT UI =================
class RobotUI {
public:
    VoiceAgent voice;

    void showRobot() {
        cout << "\n       _______"
            << "\n      |  o o  |"
            << "\n      |   ^   |"
            << "\n      |  ---  |"
            << "\n      ---------"
            << "\n        |   |"
            << "\n    ---|   |---"
            << "\n        |   |"
            << "\n       /     \\"
            << "\n      /       \\\n\n";
    }

    void greetUser(string name) {
        voice.speak("Hello " + name);
        voice.speak("I am your learning robot");
    }
};

// ================= LEARNING MODULE =================
class LearningModule {
    VoiceAgent voice;
    FileManager fm;
    string currentUser;
    bool startFresh;

    // UPDATED: Repeats voice without repeating cout
    bool playItem(string displayText, string speakText) {
        cout << displayText << endl;
        cout << "  (Press ANY KEY to continue, or '0' to SAVE & EXIT)" << endl;

        // Speak for the first time WITH the cout text
        voice.speak(speakText, true);

        while (true) {
            // Check for keyboard input for about 3 seconds (30 * 100ms)
            for (int i = 0; i < 30; i++) {
                if (_kbhit()) {
                    char key = _getch();
                    if (key == '0') {
                        cout << "\nStopping and saving progress..." << endl;
                        return false;
                    }
                    return true;
                }
                
                // WINDOWS CODE COMMENTED
                // Sleep(100);

                // MAC CODE
                usleep(100 * 1000); // 100 milliseconds
            }
            // If 3 seconds pass and no key was pressed, speak again but DO NOT print text
            voice.speak(speakText, false);
        }
    }

    int askResume(string lessonType, int totalItems) {
        if (startFresh) return 0;

        int saved = fm.loadProgress(currentUser, lessonType);
        if (saved <= 0 || saved >= totalItems)
            return 0;

        cout << "\nSaved progress found at position " << saved + 1 << " of " << totalItems << "." << endl;
        cout << "1. Continue from saved position\n2. Start from beginning\nChoice: ";

        int ch = safeInput(1, 2, "Invalid. Enter 1 or 2: ");
        if (ch == 1) return saved;
        return 0;
    }

public:
    void setUser(string username, bool fresh) {
        currentUser = username;
        startFresh = fresh;
        if (fresh)
            fm.resetProgress(username);
    }

    void alphabetLesson() {
        voice.speak("Lets learn the alphabet.");
        int start = askResume("alpha", 26);

        for (int i = start; i < 26; i++) {
            char c = 'A' + i;
            string letter(1, c);
            char c_lower = 'a' + i;
            string speakLetter(1, c_lower);

            if (!playItem("\nLetter: " + letter, speakLetter)) {
                fm.saveProgress(currentUser, "alpha", i);
                return;
            }
            fm.saveProgress(currentUser, "alpha", i + 1);
        }
        cout << "\nAlphabet lesson complete!\n";
    }

    void numberLesson() {
        voice.speak("Lets learn numbers.");
        int start = askResume("number", 100);

        for (int i = start; i < 100; i++) {
            string num = to_string(i + 1);

            if (!playItem("\nNumber: " + num, num)) {
                fm.saveProgress(currentUser, "number", i);
                return;
            }
            fm.saveProgress(currentUser, "number", i + 1);
        }
        cout << "\nNumber lesson complete!\n";
    }

    void fruitLesson() {
        string fruits[] = { "Apple", "Banana", "Orange", "Mango", "Grapes",
                            "Strawberry", "Pineapple", "Watermelon", "Peach", "Pear",
                            "Cherry", "Plum", "Kiwi", "Papaya", "Lemon",
                            "Coconut", "Fig", "Guava", "Pomegranate", "Avocado" };
        voice.speak("Lets learn fruit names.");
        int start = askResume("fruit", 20);

        for (int i = start; i < 20; i++) {
            if (!playItem("\nFruit: " + fruits[i], fruits[i])) {
                fm.saveProgress(currentUser, "fruit", i);
                return;
            }
            fm.saveProgress(currentUser, "fruit", i + 1);
        }
        cout << "\nFruit lesson complete!\n";
    }

    void animalLesson() {
        string animals[] = { "Lion", "Tiger", "Elephant", "Zebra", "Monkey",
                             "Bear", "Giraffe", "Kangaroo", "Panda", "Rhino",
                             "Hippo", "Cheetah", "Wolf", "Fox", "Deer",
                             "Rabbit", "Horse", "Cow", "Sheep", "Goat" };
        voice.speak("Lets learn animal names.");
        int start = askResume("animal", 20);

        for (int i = start; i < 20; i++) {
            if (!playItem("\nAnimal: " + animals[i], animals[i])) {
                fm.saveProgress(currentUser, "animal", i);
                return;
            }
            fm.saveProgress(currentUser, "animal", i + 1);
        }
        cout << "\nAnimal lesson complete!\n";
    }

    void start() {
        int choice;
        while (true) {
            cout << "\n--- Learning Module ---"
                << "\n1. Alphabets\n2. Numbers\n3. Fruits\n4. Animals\n5. Exit"
                << "\nChoice: ";

            choice = safeInput(1, 5, "Invalid. Enter a number between 1 and 5: ");

            if (choice == 1) alphabetLesson();
            else if (choice == 2) numberLesson();
            else if (choice == 3) fruitLesson();
            else if (choice == 4) animalLesson();
            else if (choice == 5) break;
        }
    }
};

// ================= MAIN APP =================
class KidsApp {
    FileManager fm;
    RobotUI robot;
public:
    void run() {
        int choice;
        while (true) {
            cout << "\n===== Kids Learning App ====="
                << "\n1. Login\n2. Register\n3. Exit\nChoice: ";

            choice = safeInput(1, 3, "Invalid. Enter 1, 2, or 3: ");

            if (choice == 1) {
                User user = fm.loginUser();
                if (user.name != "") {
                    robot.showRobot();
                    robot.greetUser(user.name);

                    cout << "\nDo you want to continue from last saved progress or start new?"
                        << "\n1. Continue\n2. Start New\nChoice: ";
                    int resumeChoice = safeInput(1, 2, "Invalid. Enter 1 or 2: ");
                    bool fresh = (resumeChoice == 2);

                    mainMenu(user.name, user.age, fresh);
                }
            }
            else if (choice == 2) {
                fm.registerUser();
            }
            else break;
        }
    }

    void mainMenu(string username, int age, bool fresh) {
        int choice;
        while (true) {
            cout << "\n================================" << endl;
            cout << "      MASTER HUB (Menu)         " << endl;
            cout << "================================" << endl;
            cout << "1. Learning Module (Ages 3-5)" << endl;
            cout << "2. Gaming Module (Ages 5-8)" << endl;
            cout << "3. Logout" << endl;
            cout << "Choice: ";

            choice = safeInput(1, 3, "Invalid. Enter 1, 2, or 3: ");

            if (choice == 1) {
                LearningModule lm;
                lm.setUser(username, fresh);
                lm.start(); // This is the function from your learning file
            }
            else if (choice == 2) {
                if (age >= 5 && age <= 8) {
                    runall(); // <--- This is the function from your gaming.h file!
                } else {
                    cout << "\nSorry, your age (" << age << ") is not eligible for this module. It is only for children aged 5 to 8!" << endl;
                }
            }
            else {
                cout << "Logging out..." << endl;
                break;
            }
        }
    }
};

#endif