#ifndef UI_H
#define UI_H

// ================================================================
//  ui.h  —  SFML 3.0 frontend for Kids Learning App
//  Connects to: learing.h (KidsApp backend)
//  Compile:
//    g++ -std=c++17 main_ui.cpp -o app \
//        -I/opt/homebrew/include \
//        -L/opt/homebrew/lib \
//        -lsfml-graphics -lsfml-window -lsfml-system -lsfml-audio
// ================================================================

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>
#include <SFML/Audio.hpp>
#include <string>
#include <cstdint>
#include <vector>
#include <functional>
#include <algorithm>
#include <optional>
#include <fstream>
#include <iostream>
#include <cmath>

#define private public
#define protected public
#include "gaming.h"
#undef private
#undef protected

#include "learing.h"   // KidsApp, LearningModule, FileManager etc.
using namespace std;

// ───────────────────────────────────────────────────────────────
//  COLOUR PALETTE  (clean modern flat)
// ───────────────────────────────────────────────────────────────
namespace Palette {
    // backgrounds
    const sf::Color BG        {15,  17,  26,  255};   // near-black navy
    const sf::Color CARD      {26,  30,  46,  255};   // dark card
    const sf::Color CARD_HOV  {36,  42,  64,  255};   // hovered card

    // accents
    const sf::Color ACCENT    {99,  102, 241, 255};   // indigo
    const sf::Color ACCENT2   {16,  185, 129, 255};   // emerald
    const sf::Color ACCENT3   {245, 158, 11,  255};   // amber
    const sf::Color DANGER    {239, 68,  68,  255};   // red

    // text
    const sf::Color TEXT      {236, 237, 243, 255};   // near-white
    const sf::Color SUBTEXT   {148, 151, 172, 255};   // muted
    const sf::Color WHITE     {255, 255, 255, 255};

    // input field
    const sf::Color INPUT_BG  {20,  23,  38,  255};
    const sf::Color INPUT_BD  {60,  65,  95,  255};
    const sf::Color INPUT_ACT {99,  102, 241, 200};
}

// ───────────────────────────────────────────────────────────────
//  SCREEN ENUM
// ───────────────────────────────────────────────────────────────
enum class Screen {
    SPLASH,
    MAIN_MENU,
    LOGIN,
    REGISTER,
    RESUME_PROMPT,
    HUB,
    LEARNING_MENU,
    GAME_MENU,
    LEARNING_LESSON,
    GAME_NUMBER_GUESS,
    GAME_PICTURE_QUIZ,
    GAME_MISSING_LETTER,
    GAME_COLOR_GUESS,
    MESSAGE
};

// ================= UI COMPONENTS (BUTTON, INPUT, ETC.) =================

//  BUTTON  —  rounded rect with hover/click animation
struct Button {
    sf::RectangleShape shape;
    sf::Text           label;
    sf::Color          normalCol;
    sf::Color          hoverCol;
    bool               hovered = false;

    Button(const sf::Font& font,
           const std::string& text,
           sf::Vector2f pos, sf::Vector2f size,
           sf::Color bg, sf::Color hover,
           unsigned int fontSize = 20)
        : normalCol(bg), hoverCol(hover),
          label(font, text, fontSize)
    {
        shape.setSize(size);
        shape.setPosition(pos);
        shape.setFillColor(bg);

        // centre text inside button
        sf::FloatRect tb = label.getLocalBounds();
        label.setOrigin({tb.position.x + tb.size.x / 2.f,
                         tb.position.y + tb.size.y / 2.f});
        label.setPosition({pos.x + size.x / 2.f,
                           pos.y + size.y / 2.f});
        label.setFillColor(Palette::WHITE);
    }

    void update(sf::Vector2f mouse) {
        hovered = shape.getGlobalBounds().contains(mouse);
        shape.setFillColor(hovered ? hoverCol : normalCol);
    }

    bool clicked(sf::Vector2f mouse) const {
        return shape.getGlobalBounds().contains(mouse);
    }

    void draw(sf::RenderWindow& w) const {
        w.draw(shape);
        w.draw(label);
    }
};

//  INPUT FIELD
struct InputField {
    sf::RectangleShape box;
    sf::Text           displayText;   // what user typed (or masked)
    sf::Text           placeholder;
    std::string        value;
    bool               active    = false;
    bool               isPassword= false;
    bool               numericOnly = false;
    bool               alphaOnly = false;
    std::string        hint;

    InputField(const sf::Font& font, const std::string& ph,
               sf::Vector2f pos, sf::Vector2f size,
               bool pwd = false, bool numOnly = false, bool alpOnly = false)
        : isPassword(pwd), numericOnly(numOnly), alphaOnly(alpOnly), hint(ph),
          displayText(font, "", 18),
          placeholder(font, ph, 18)
    {
        box.setSize(size);
        box.setPosition(pos);
        box.setFillColor(Palette::INPUT_BG);
        box.setOutlineThickness(2.f);
        box.setOutlineColor(Palette::INPUT_BD);

        displayText.setFillColor(Palette::TEXT);
        displayText.setPosition({pos.x + 14.f, pos.y + size.y/2.f - 11.f});

        placeholder.setFillColor(Palette::SUBTEXT);
        placeholder.setPosition({pos.x + 14.f, pos.y + size.y/2.f - 11.f});
    }

    void setActive(bool a) {
        active = a;
        box.setOutlineColor(a ? Palette::INPUT_ACT : Palette::INPUT_BD);
    }

    void handleTextEntered(std::uint32_t unicode) {
        if (!active) return;
        if (unicode == 8 && !value.empty()) {  // backspace
            value.pop_back();
        } else if (unicode >= 32 && unicode < 127) {
            char c = static_cast<char>(unicode);
            if (numericOnly) {
                if (c >= '0' && c <= '9') value += c;
            } else if (alphaOnly) {
                if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) value += c;
            } else {
                value += c;
            }
        }
        std::string shown = isPassword ? std::string(value.size(), '*') : value;
        displayText.setString(shown);
    }

    bool clicked(sf::Vector2f mouse) const {
        return box.getGlobalBounds().contains(mouse);
    }

    void draw(sf::RenderWindow& w) const {
        w.draw(box);
        if (value.empty()) w.draw(placeholder);
        else               w.draw(displayText);
    }
};

//  PROGRESS BAR
struct ProgressBar {
    sf::RectangleShape bg, fill;

    ProgressBar(sf::Vector2f pos, sf::Vector2f size) {
        bg.setSize(size);
        bg.setPosition(pos);
        bg.setFillColor(Palette::CARD);

        fill.setSize({0.f, size.y});
        fill.setPosition(pos);
        fill.setFillColor(Palette::ACCENT2);
    }

    void setProgress(float ratio) {   // 0.0 to 1.0
        float w = bg.getSize().x * std::clamp(ratio, 0.f, 1.f);
        fill.setSize({w, bg.getSize().y});
    }

    void draw(sf::RenderWindow& w) const {
        w.draw(bg);
        w.draw(fill);
    }
};

//  NOTIFICATION TOAST
struct Toast {
    sf::RectangleShape box;
    std::string        msgText;
    const sf::Font* fontPtr;
    sf::Clock          timer;
    float              duration;
    bool               visible;

    Toast() : box(sf::Vector2f(0.f, 0.f)), msgText(""), fontPtr(nullptr), duration(2.f), visible(false) {}

    void init(const sf::Font& font) {
        box.setSize(sf::Vector2f(420.f, 54.f));
        fontPtr = &font;
    }

    void show(const std::string& text, sf::Vector2u winSize,
              sf::Color col = Palette::ACCENT2, float dur = 2.f) {
        box.setFillColor(col);
        duration = dur;
        msgText = text;
        float bx = (winSize.x - box.getSize().x) / 2.f;
        float by = winSize.y - 80.f;
        box.setPosition(sf::Vector2f(bx, by));
        timer.restart();
        visible = true;
    }

    void update() {
        if (visible && timer.getElapsedTime().asSeconds() > duration)
            visible = false;
    }

    void draw(sf::RenderWindow& w) const {
        if (!visible || !fontPtr) return;
        w.draw(box);
        sf::Text msg(*fontPtr, msgText, 17);
        msg.setFillColor(Palette::WHITE);
        msg.setPosition(sf::Vector2f(box.getPosition().x + 20.f, box.getPosition().y + 14.f));
        w.draw(msg);
    }
};

// ================= MAIN APP =================

class SFMLApp {
private:
    // window
    sf::RenderWindow window;
    sf::Font         font;

    // state
    Screen      screen     = Screen::SPLASH;
    std::string loggedUser = "";
    int         userAge    = 0;
    bool        startFresh = false;

    // backend
    FileManager fm;

    // toast
    Toast toast;

    // Audio assets
    sf::SoundBuffer clickBuffer, correctBuffer, wrongBuffer;
    std::optional<sf::Sound> clickSound, correctSound, wrongSound;

    // GUI Game Variables
    int gameScore = 0;
    int gameSecret = 0;
    int gameAttempt = 0;
    std::string gameString = "";
    std::vector<Button> gameActionBtns;
    std::optional<InputField> gameInput;
    sf::Texture gameTexture;
    std::optional<sf::Sprite> gameSprite;
    
    std::vector<std::string> picNames = {"Apple", "Tree", "Car", "House", "Cat", "Dog", "Sun", "Star", "Book", "Ball"};
    std::vector<std::string> colorNames = {"Red", "Green", "Blue", "Yellow", "Purple", "Orange", "Cyan", "Brown", "Pink", "Black", "White", "Gray"};
    std::vector<sf::Color> colorVals = {
        sf::Color::Red, sf::Color::Green, sf::Color::Blue, sf::Color::Yellow,
        sf::Color(128,0,128), sf::Color(255,165,0), sf::Color(0,255,255), sf::Color(139,69,19),
        sf::Color(255,192,203), sf::Color::Black, sf::Color::White, sf::Color(128,128,128)
    };

    // splash clock
    sf::Clock splashClock;

    // UI state pointers
    InputField* activeField = nullptr;

    // Vectors to store transient dynamic buttons/inputs between render and logical steps
    std::vector<Button> mainBtns;
    std::vector<InputField> loginFields;
    std::vector<Button>     loginBtns;
    std::vector<InputField> regFields;
    std::vector<Button>     regBtns;
    std::vector<Button>     resumeBtns;
    std::vector<Button>     hubBtns;
    std::vector<Button>     learnBtns;
    std::vector<Button>     lessonBtns;
    std::vector<Button>     gameBtns;

    // Current state details
    std::string currentLesson;
    struct LessonItem { std::string display; std::string speak; };
    std::vector<LessonItem> lessonItems;
    int    lessonIndex = 0;
    int    lessonTotal = 0;
    float  repeatTimer = 0.f;
    float  REPEAT_INTERVAL = 3.f;
    sf::Clock lessonClock;

public:
    SFMLApp() : window(sf::VideoMode({900u, 620u}), "Kids Learning App", sf::Style::Titlebar | sf::Style::Close)
    {
        window.setFramerateLimit(60);
        if (!font.openFromFile("Arial.ttf") && !font.openFromFile("arial.ttf")) {
            std::cerr << "Failed to load font Arial.ttf\n";
        }
        (void)clickBuffer.loadFromFile("assets/sounds/click.wav");
        (void)correctBuffer.loadFromFile("assets/sounds/correct.wav");
        (void)wrongBuffer.loadFromFile("assets/sounds/wrong.wav");
        clickSound.emplace(clickBuffer);
        correctSound.emplace(correctBuffer);
        wrongSound.emplace(wrongBuffer);
        if (clickSound) clickSound->setVolume(6.f);
        if (correctSound) correctSound->setVolume(75.f);
        if (wrongSound) wrongSound->setVolume(75.f);
        toast.init(font);
        buildMainMenu();
    }

    void run() {
        while (window.isOpen()) {
            sf::Vector2i mouseI = sf::Mouse::getPosition(window);
            sf::Vector2f mouse{(float)mouseI.x, (float)mouseI.y};

            while (auto event = window.pollEvent()) {
                if (event->is<sf::Event::Closed>()) { window.close(); }
                
                if (auto* te = event->getIf<sf::Event::TextEntered>()) {
                    if (screen == Screen::LOGIN) {
                        for (auto& f : loginFields) if (f.active) f.handleTextEntered(te->unicode);
                    }
                    if (screen == Screen::REGISTER) {
                        for (auto& f : regFields) if (f.active) f.handleTextEntered(te->unicode);
                    }
                    if (screen == Screen::GAME_NUMBER_GUESS || screen == Screen::GAME_MISSING_LETTER) {
                        if (gameInput && gameInput->active) gameInput->handleTextEntered(te->unicode);
                    }
                }

                if (auto* kp = event->getIf<sf::Event::KeyPressed>()) {
                    if (kp->code == sf::Keyboard::Key::Escape) {
                        if (screen == Screen::LOGIN || screen == Screen::REGISTER) screen = Screen::MAIN_MENU;
                    }
                    if (kp->code == sf::Keyboard::Key::Enter) {
                        if (screen == Screen::LOGIN) attemptLogin();
                        if (screen == Screen::REGISTER) attemptRegister();
                    }
                    if (screen == Screen::LEARNING_LESSON) {
                        if (kp->code == sf::Keyboard::Key::Right || kp->code == sf::Keyboard::Key::Space) {
                            fm.saveProgress(loggedUser, currentLesson, lessonIndex+1);
                            if (lessonIndex+1 >= lessonTotal) {
                                toast.show("Lesson complete!", window.getSize(), Palette::ACCENT2, 2.5f);
                                screen = Screen::LEARNING_MENU; buildLearningMenu();
                            } else {
                                lessonIndex++;
                                speakItem(lessonIndex);
                            }
                        }
                        if (kp->code == sf::Keyboard::Key::Left) {
                            if (lessonIndex > 0) { lessonIndex--; speakItem(lessonIndex); }
                        }
                    }
                }

                if (auto* mc = event->getIf<sf::Event::MouseButtonPressed>()) {
                    if (mc->button == sf::Mouse::Button::Left) {
                        sf::Vector2f mf{(float)mc->position.x, (float)mc->position.y};
                        playClick();
                        switch (screen) {
                            case Screen::MAIN_MENU:      handleMainMenu(mf);        break;
                            case Screen::LOGIN:          handleLoginClick(mf);      break;
                            case Screen::REGISTER:       handleRegisterClick(mf);   break;
                            case Screen::RESUME_PROMPT:  handleResumeClick(mf);     break;
                            case Screen::HUB:            handleHubClick(mf);        break;
                            case Screen::LEARNING_MENU:  handleLearningMenuClick(mf); break;
                            case Screen::LEARNING_LESSON: handleLessonClick(mf);   break;
                            case Screen::GAME_MENU:      handleGameMenuClick(mf);   break;
                            case Screen::GAME_NUMBER_GUESS: handleNumberGuessClick(mf); break;
                            case Screen::GAME_PICTURE_QUIZ: handlePictureQuizClick(mf); break;
                            case Screen::GAME_MISSING_LETTER: handleMissingLetterClick(mf); break;
                            case Screen::GAME_COLOR_GUESS: handleColorGuessClick(mf); break;
                            default: break;
                        }
                    }
                }
            }
            
            toast.update();
            switch (screen) {
                case Screen::SPLASH:          drawSplash();              break;
                case Screen::MAIN_MENU:       drawMainMenu(mouse);       break;
                case Screen::LOGIN:           drawLoginScreen(mouse);    break;
                case Screen::REGISTER:        drawRegisterScreen(mouse); break;
                case Screen::RESUME_PROMPT:   drawResumePrompt(mouse);   break;
                case Screen::HUB:             drawHub(mouse);            break;
                case Screen::LEARNING_MENU:   drawLearningMenu(mouse);   break;
                case Screen::LEARNING_LESSON: drawLesson(mouse);         break;
                case Screen::GAME_MENU:       drawGameMenu(mouse);       break;
                case Screen::GAME_NUMBER_GUESS: drawNumberGuess(mouse);  break;
                case Screen::GAME_PICTURE_QUIZ: drawPictureQuiz(mouse);  break;
                case Screen::GAME_MISSING_LETTER: drawMissingLetter(mouse); break;
                case Screen::GAME_COLOR_GUESS: drawColorGuess(mouse);    break;
                default: break;
            }
            window.display();
        }
    }

private:
    void drawSplash() {
        window.clear(Palette::BG);
        float t = splashClock.getElapsedTime().asSeconds();
        float pulse = 90.f + 8.f * std::sin(t * 2.f);
        sf::CircleShape orb(pulse);
        orb.setFillColor({99, 102, 241, 60});
        orb.setOrigin({pulse, pulse});
        orb.setPosition({window.getSize().x / 2.f,
                         window.getSize().y / 2.f - 40.f});
        window.draw(orb);

        sf::CircleShape orb2(pulse * 0.6f);
        orb2.setFillColor({16, 185, 129, 80});
        orb2.setOrigin({pulse*0.6f, pulse*0.6f});
        orb2.setPosition({window.getSize().x / 2.f,
                          window.getSize().y / 2.f - 40.f});
        window.draw(orb2);

        auto title = makeText("Kids Learning App", 46, Palette::TEXT,
                              {0, window.getSize().y/2.f + 80.f}, true);
        auto sub   = makeText("Loading...", 20, Palette::SUBTEXT,
                              {0, window.getSize().y/2.f + 140.f}, true);
        window.draw(title);
        window.draw(sub);

        if (splashClock.getElapsedTime().asSeconds() > 2.2f)
            screen = Screen::MAIN_MENU;
    }

    void buildMainMenu() {
        mainBtns.clear();
        float cx = window.getSize().x / 2.f;
        float cy = window.getSize().y / 2.f;
        mainBtns.push_back({font, "Login",    {cx-160,cy-60}, {320,54}, Palette::ACCENT,   {80,83,220,255}});
        mainBtns.push_back({font, "Register", {cx-160,cy+10}, {320,54}, Palette::ACCENT2,  {12,150,105,255}});
        mainBtns.push_back({font, "Exit",     {cx-160,cy+80}, {320,54}, Palette::CARD,     Palette::DANGER});
    }

    void drawMainMenu(sf::Vector2f mouse) {
        window.clear(Palette::BG);
        drawDecorCircles();

        sf::RectangleShape card({380.f, 80.f});
        card.setFillColor(Palette::CARD);
        card.setPosition({window.getSize().x/2.f-190.f, 80.f});
        window.draw(card);

        auto logo = makeText("Kids Learning App", 30, Palette::ACCENT, {0, 100.f}, true);
        auto ver  = makeText("v1.0", 16, Palette::SUBTEXT, {0, 138.f}, true);
        window.draw(logo);
        window.draw(ver);

        for (auto& b : mainBtns) { b.update(mouse); b.draw(window); }
        toast.draw(window);
    }

    bool handleMainMenu(sf::Vector2f mouse) {
        if (mainBtns[0].clicked(mouse)) { screen = Screen::LOGIN;    buildLoginScreen(); }
        if (mainBtns[1].clicked(mouse)) { screen = Screen::REGISTER; buildRegisterScreen(); }
        if (mainBtns[2].clicked(mouse)) { window.close(); return false; }
        return true;
    }

    // ================= LOGIN SYSTEM =================

    void buildLoginScreen() {
        loginFields.clear(); loginBtns.clear();
        float cx = window.getSize().x / 2.f;
        loginFields.push_back({font, "Username", {cx-170,220}, {340,50}});
        loginFields.push_back({font, "Password", {cx-170,290}, {340,50}, true});
        loginBtns.push_back({font,"Login",  {cx-170,360},{340,50}, Palette::ACCENT,{80,83,220,255}});
        loginBtns.push_back({font,"Back",   {cx-170,424},{340,44}, Palette::CARD,Palette::DANGER, 17});
    }

    void drawLoginScreen(sf::Vector2f mouse) {
        window.clear(Palette::BG);
        drawDecorCircles();
        drawFormCard(180.f, 330.f);
        auto h = makeText("Welcome Back", 32, Palette::TEXT, {0,100.f}, true);
        auto s = makeText("Sign in to continue", 17, Palette::SUBTEXT, {0,145.f}, true);
        window.draw(h); window.draw(s);
        for (auto& f : loginFields) f.draw(window);
        for (auto& b : loginBtns)  { b.update(mouse); b.draw(window); }
        toast.draw(window);
    }

    void handleLoginClick(sf::Vector2f mouse) {
        for (auto& f : loginFields) {
            f.setActive(f.clicked(mouse));
            if (f.clicked(mouse)) activeField = &f;
        }
        if (loginBtns[0].clicked(mouse)) attemptLogin();
        if (loginBtns[1].clicked(mouse)) {
            screen = Screen::MAIN_MENU; activeField = nullptr;
        }
    }

    void attemptLogin() {
        std::string name = loginFields[0].value;
        std::string pass = loginFields[1].value;
        if (name.empty() || pass.empty()) {
            toast.show("Please fill all fields", window.getSize(), Palette::DANGER);
            return;
        }
        std::ifstream file("users.txt");
        std::string line;
        bool found = false;
        int foundAge = 0;
        while (std::getline(file, line)) {
            size_t p1 = line.find(',');
            size_t p2 = line.find(',', p1+1);
            if (p1==std::string::npos||p2==std::string::npos) continue;
            std::string n = line.substr(0, p1);
            int    a = std::stoi(line.substr(p1+1, p2-p1-1));
            std::string p = line.substr(p2+1);
            if (n==name && p==pass) { found=true; foundAge=a; break; }
        }
        if (found) {
            loggedUser = name;
            userAge    = foundAge;
            activeField = nullptr;
            toast.show("Login successful! Welcome " + name, window.getSize(), Palette::ACCENT2);
            speakPrompt("Welcome! Hello " + name + ", I am your learning robot.");
            if (hasAnyProgress(loggedUser)) {
                screen = Screen::RESUME_PROMPT;
                buildResumePrompt();
            } else {
                startFresh = true;
                screen = Screen::HUB;
                buildHub();
            }
        } else {
            toast.show("Invalid username or password", window.getSize(), Palette::DANGER);
        }
    }

    // ================= REGISTER SYSTEM =================

    void buildRegisterScreen() {
        regFields.clear(); regBtns.clear();
        float cx = window.getSize().x / 2.f;
        regFields.push_back({font, "Full Name", {cx-170,210},{340,50}});
        regFields.push_back({font, "Age (number)", {cx-170,278},{340,50}});
        regFields.push_back({font, "Password",  {cx-170,346},{340,50},true});
        regBtns.push_back({font,"Create Account",{cx-170,416},{340,50}, Palette::ACCENT2,{12,150,105,255}});
        regBtns.push_back({font,"Back",          {cx-170,480},{340,44}, Palette::CARD,Palette::DANGER,17});
    }

    void drawRegisterScreen(sf::Vector2f mouse) {
        window.clear(Palette::BG);
        drawDecorCircles();
        drawFormCard(170.f, 380.f);
        auto h = makeText("Create Account", 32, Palette::TEXT, {0,95.f}, true);
        auto s = makeText("Join the learning adventure", 17, Palette::SUBTEXT, {0,138.f}, true);
        window.draw(h); window.draw(s);
        for (auto& f : regFields) f.draw(window);
        for (auto& b : regBtns)  { b.update(mouse); b.draw(window); }
        toast.draw(window);
    }

    void handleRegisterClick(sf::Vector2f mouse) {
        for (auto& f : regFields) {
            f.setActive(f.clicked(mouse));
            if (f.clicked(mouse)) activeField = &f;
        }
        if (regBtns[0].clicked(mouse)) attemptRegister();
        if (regBtns[1].clicked(mouse)) {
            screen = Screen::MAIN_MENU; activeField = nullptr;
        }
    }

    void attemptRegister() {
        std::string name = regFields[0].value;
        std::string ageS = regFields[1].value;
        std::string pass = regFields[2].value;
        if (name.empty()||ageS.empty()||pass.empty()) {
            toast.show("Please fill all fields", window.getSize(), Palette::DANGER);
            return;
        }
        int age = 0;
        try { age = std::stoi(ageS); } catch(...) {
            toast.show("Age must be a number", window.getSize(), Palette::DANGER);
            return;
        }
        std::ofstream file("users.txt", std::ios::app);
        file << name << "," << age << "," << pass << "\n";
        file.close();
        toast.show("Account created! Please login.", window.getSize(), Palette::ACCENT2, 2.5f);
        screen = Screen::MAIN_MENU;
        activeField = nullptr;
    }

    // ================= HUB / DASHBOARD =================

    void buildResumePrompt() {
        resumeBtns.clear();
        float cx = window.getSize().x / 2.f;
        resumeBtns.push_back({font,"Continue from last session",{cx-200,300},{400,56}, Palette::ACCENT,{80,83,220,255}, 19});
        resumeBtns.push_back({font,"Start fresh",               {cx-200,372},{400,56}, Palette::ACCENT2,{12,150,105,255},19});
    }

    void drawResumePrompt(sf::Vector2f mouse) {
        window.clear(Palette::BG);
        drawDecorCircles();
        auto h = makeText("Hello, " + loggedUser + "!", 36, Palette::TEXT, {0,160.f}, true);
        auto s = makeText("How would you like to start today?", 20, Palette::SUBTEXT, {0,210.f}, true);
        window.draw(h); window.draw(s);
        for (auto& b : resumeBtns) { b.update(mouse); b.draw(window); }
        toast.draw(window);
    }

    void handleResumeClick(sf::Vector2f mouse) {
        if (resumeBtns[0].clicked(mouse)) {
            startFresh = false;
            screen = Screen::HUB; buildHub();
        }
        if (resumeBtns[1].clicked(mouse)) {
            startFresh = true;
            fm.resetProgress(loggedUser);
            screen = Screen::HUB; buildHub();
        }
    }

    void buildHub() {
        hubBtns.clear();
        float cx = window.getSize().x / 2.f;
        hubBtns.push_back({font,"Learning Module\n(Ages 3-5)", {cx-220,240},{200,120}, Palette::ACCENT,{80,83,220,255},18});
        hubBtns.push_back({font,"Gaming Module\n(Ages 5-8)",  {cx+20, 240},{200,120}, Palette::ACCENT3,{200,128,8,255},18});
        hubBtns.push_back({font,"Logout", {cx-100,400},{200,50}, Palette::CARD, Palette::DANGER,17});
    }

    void drawHub(sf::Vector2f mouse) {
        window.clear(Palette::BG);
        drawDecorCircles();
        sf::RectangleShape bar({(float)window.getSize().x, 70.f});
        bar.setFillColor(Palette::CARD);
        bar.setPosition({0.f, 0.f});
        window.draw(bar);

        auto hdr = makeText("Learning Hub", 26, Palette::TEXT, {0,20.f}, true);
        auto usr = makeText("Logged in: " + loggedUser + "  |  Age: " + std::to_string(userAge), 16, Palette::SUBTEXT, {24.f, 26.f});
        window.draw(hdr); window.draw(usr);
        drawProgressOverview();

        for (auto& b : hubBtns) { b.update(mouse); b.draw(window); }
        toast.draw(window);
    }

    void handleHubClick(sf::Vector2f mouse) {
        if (hubBtns[0].clicked(mouse)) {
            screen = Screen::LEARNING_MENU; buildLearningMenu();
        }
        if (hubBtns[1].clicked(mouse)) {
            if (userAge >= 5 && userAge <= 8) {
                screen = Screen::GAME_MENU; buildGameMenu();
            } else {
                toast.show("Gaming module is for ages 5-8", window.getSize(), Palette::DANGER, 2.5f);
            }
        }
        if (hubBtns[2].clicked(mouse)) {
            loggedUser = ""; userAge = 0;
            screen = Screen::MAIN_MENU;
            buildMainMenu();
        }
    }

    void drawProgressOverview() {
        struct LessonInfo { std::string key; std::string label; int total; sf::Color col; };
        LessonInfo lessons[] = {
            {"alpha",  "Alphabets", 26, Palette::ACCENT},
            {"number", "Numbers",   100, Palette::ACCENT2},
            {"fruit",  "Fruits",     20, Palette::ACCENT3},
            {"animal", "Animals",    20, Palette::DANGER}
        };
        float startX = window.getSize().x/2.f - 340.f;
        float y = 100.f;
        for (int i = 0; i < 4; i++) {
            auto& l = lessons[i];
            int saved = fm.loadProgress(loggedUser, l.key);
            if (saved < 0) saved = 0;
            float ratio = (float)saved / l.total;

            auto lbl = makeText(l.label, 14, Palette::SUBTEXT, {startX + i*170.f, y});
            auto pct = makeText(std::to_string(saved)+"/"+std::to_string(l.total), 14, l.col, {startX + i*170.f + 110.f, y});
            window.draw(lbl); window.draw(pct);

            ProgressBar pb({startX + i*170.f, y+22.f}, {155.f, 8.f});
            pb.fill.setFillColor(l.col);
            pb.setProgress(ratio);
            pb.draw(window);
        }
    }

    // ================= LEARNING MODULE =================

    void buildLearningMenu() {
        learnBtns.clear();
        float cx = window.getSize().x / 2.f;
        learnBtns.push_back({font,"Alphabets",{cx-180,200},{340,56}, Palette::ACCENT,{80,83,220,255}});
        learnBtns.push_back({font,"Numbers",  {cx-180,270},{340,56}, Palette::ACCENT2,{12,150,105,255}});
        learnBtns.push_back({font,"Fruits",   {cx-180,340},{340,56}, Palette::ACCENT3,{200,128,8,255}});
        learnBtns.push_back({font,"Animals",  {cx-180,410},{340,56}, Palette::DANGER, {190,40,40,255}});
        learnBtns.push_back({font,"Back",     {cx-180,490},{340,44}, Palette::CARD,Palette::DANGER,17});
    }

    void drawLearningMenu(sf::Vector2f mouse) {
        window.clear(Palette::BG);
        drawDecorCircles();
        auto h = makeText("Learning Module", 34, Palette::TEXT, {0,120.f}, true);
        auto s = makeText("Choose a topic to learn", 18, Palette::SUBTEXT, {0,163.f}, true);
        window.draw(h); window.draw(s);
        for (auto& b : learnBtns) { b.update(mouse); b.draw(window); }
        toast.draw(window);
    }

    void handleLearningMenuClick(sf::Vector2f mouse) {
        std::string keys[] = {"alpha","number","fruit","animal"};
        for (int i = 0; i < 4; i++) {
            if (learnBtns[i].clicked(mouse)) {
                currentLesson = keys[i];
                screen = Screen::LEARNING_LESSON;
                buildLesson();
            }
        }
        if (learnBtns[4].clicked(mouse)) {
            screen = Screen::HUB; buildHub();
        }
    }

    void buildLesson() {
        lessonItems.clear();
        if (currentLesson == "alpha") {
            for (char c = 'A'; c <= 'Z'; c++) {
                char lowerC = tolower(c);
                lessonItems.push_back({std::string(1,c), std::string(1,lowerC) + "."}); 
            }
        } else if (currentLesson == "number") {
            for (int i = 1; i <= 100; i++) {
                std::string s = std::to_string(i);
                lessonItems.push_back({s, s});
            }
        } else if (currentLesson == "fruit") {
            for (auto& f : {"Apple", "Banana", "Orange", "Mango", "Grapes",
                            "Strawberry", "Pineapple", "Watermelon", "Peach", "Pear",
                            "Cherry", "Plum", "Kiwi", "Papaya", "Lemon",
                            "Coconut", "Fig", "Guava", "Pomegranate", "Avocado"})
                lessonItems.push_back({f, f});
        } else {
            for (auto& a : {"Lion", "Tiger", "Elephant", "Zebra", "Monkey",
                             "Bear", "Giraffe", "Kangaroo", "Panda", "Rhino",
                             "Hippo", "Cheetah", "Wolf", "Fox", "Deer",
                             "Rabbit", "Horse", "Cow", "Sheep", "Goat"})
                lessonItems.push_back({a, a});
        }
        lessonTotal = (int)lessonItems.size();

        int saved = startFresh ? 0 : fm.loadProgress(loggedUser, currentLesson);
        if (saved < 0 || saved >= lessonTotal) saved = 0;
        lessonIndex = saved;
        lessonClock.restart();
        repeatTimer = 0.f;
        speakItem(lessonIndex);

        lessonBtns.clear();
        float cx = window.getSize().x / 2.f;
        lessonBtns.push_back({font,"Next  →", {cx-160,440},{150,50}, Palette::ACCENT,{80,83,220,255}});
        lessonBtns.push_back({font,"← Back", {cx+10, 440},{150,50}, Palette::CARD,Palette::CARD_HOV});
        lessonBtns.push_back({font,"Stop & Save",{cx-80,504},{160,44}, Palette::DANGER,{190,40,40,255},16});
    }

    void drawLesson(sf::Vector2f mouse) {
        window.clear(Palette::BG);
        float elapsed = lessonClock.getElapsedTime().asSeconds();
        if (elapsed - repeatTimer >= REPEAT_INTERVAL) {
            repeatTimer = elapsed;
            speakItem(lessonIndex);
        }
        drawDecorCircles();

        std::string lessonName;
        if (currentLesson=="alpha")  lessonName="Alphabets";
        else if (currentLesson=="number") lessonName="Numbers";
        else if (currentLesson=="fruit")  lessonName="Fruits";
        else lessonName="Animals";

        auto h  = makeText(lessonName, 28, Palette::ACCENT, {0,60.f}, true);
        window.draw(h);

        ProgressBar pb({window.getSize().x/2.f-200.f, 104.f}, {400.f, 8.f});
        pb.setProgress((float)(lessonIndex+1)/lessonTotal);
        pb.draw(window);

        auto pct = makeText(std::to_string(lessonIndex+1)+"/"+std::to_string(lessonTotal), 15, Palette::SUBTEXT, {0,115.f}, true);
        window.draw(pct);

        sf::RectangleShape card({340.f, 200.f});
        card.setFillColor(Palette::CARD);
        card.setPosition({window.getSize().x/2.f-170.f, 160.f});
        window.draw(card);

        auto item = makeText(lessonItems[lessonIndex].display, 90, Palette::TEXT, {0,190.f}, true);
        window.draw(item);

        auto hint = makeText("Robot is speaking — press Next for next item", 15, Palette::SUBTEXT, {0,375.f}, true);
        window.draw(hint);

        for (auto& b : lessonBtns) { b.update(mouse); b.draw(window); }
        toast.draw(window);
    }

    void handleLessonClick(sf::Vector2f mouse) {
        if (lessonBtns[0].clicked(mouse)) {  // Next
            fm.saveProgress(loggedUser, currentLesson, lessonIndex+1);
            if (lessonIndex+1 >= lessonTotal) {
                toast.show("Lesson complete! Well done!", window.getSize(), Palette::ACCENT2, 2.5f);
                screen = Screen::LEARNING_MENU; buildLearningMenu();
            } else {
                lessonIndex++;
                speakItem(lessonIndex);
            }
        }
        if (lessonBtns[1].clicked(mouse)) {  // Back (prev)
            if (lessonIndex > 0) {
                lessonIndex--;
                speakItem(lessonIndex);
            }
        }
        if (lessonBtns[2].clicked(mouse)) {  // Stop & Save
            fm.saveProgress(loggedUser, currentLesson, lessonIndex);
            toast.show("Progress saved!", window.getSize(), Palette::ACCENT2);
            screen = Screen::LEARNING_MENU; buildLearningMenu();
        }
    }

    // ================= GAME MENU =================

    void buildGameMenu() {
        gameBtns.clear();
        float cx = window.getSize().x / 2.f;
        std::vector<std::pair<std::string,sf::Color>> games = {
            {"Number Guess",  Palette::ACCENT},
            {"Picture Quiz",  Palette::ACCENT2},
            {"Missing Letter",Palette::ACCENT3},
            {"Color Guess",   Palette::DANGER}
        };
        for (int i = 0; i < 4; i++) {
            gameBtns.push_back({font, games[i].first, {cx-180.f, 200.f+i*72.f},{340,58}, games[i].second, Palette::CARD_HOV});
        }
        gameBtns.push_back({font,"Back",{cx-180,500},{340,44}, Palette::CARD,Palette::DANGER,17});
    }

    void drawGameMenu(sf::Vector2f mouse) {
        window.clear(Palette::BG);
        drawDecorCircles();
        auto h = makeText("Gaming Module", 34, Palette::TEXT, {0,120.f}, true);
        int totalScore = fm.loadProgress(loggedUser, "gamescore");
        if (totalScore < 0) totalScore = 0;
        auto s = makeText("Total Score: " + std::to_string(totalScore) + " | Pick a game and play!", 18, Palette::ACCENT3, {0,163.f}, true);
        window.draw(h); window.draw(s);
        for (auto& b : gameBtns) { b.update(mouse); b.draw(window); }
        toast.draw(window);
    }

    void handleGameMenuClick(sf::Vector2f mouse) {
        if (gameBtns[0].clicked(mouse)) { 
            screen = Screen::GAME_NUMBER_GUESS; buildNumberGuess(); 
            speakPrompt("Guess the right number which comes after.");
        }
        if (gameBtns[1].clicked(mouse)) { 
            screen = Screen::GAME_PICTURE_QUIZ; buildPictureQuiz(); 
            speakPrompt("Select the right picture.");
        }
        if (gameBtns[2].clicked(mouse)) { 
            screen = Screen::GAME_MISSING_LETTER; buildMissingLetter(); 
            speakPrompt("Type the missing letter.");
        }
        if (gameBtns[3].clicked(mouse)) { 
            screen = Screen::GAME_COLOR_GUESS; buildColorGuess(); 
            speakPrompt("Guess the correct color.");
        }
        if (gameBtns[4].clicked(mouse)) { screen = Screen::HUB; buildHub(); }
    }

    // ================= GAME: NUMBER GUESS =================

    void buildNumberGuess() {
        gameSecret = rand() % 100 + 1;
        gameScore = 0;
        float cx = window.getSize().x / 2.f;
        gameInput.emplace(font, "Enter a number...", sf::Vector2f(cx-170,300), sf::Vector2f(340,50), false, true);
        gameActionBtns.clear();
        gameActionBtns.push_back({font, "Guess", {cx-170,380}, {160,50}, Palette::ACCENT, {80,83,220,255}});
        gameActionBtns.push_back({font, "Exit", {cx+10,380}, {160,50}, Palette::DANGER, {190,40,40,255}});
    }

    void drawNumberGuess(sf::Vector2f mouse) {
        window.clear(Palette::BG); drawDecorCircles();
        auto h = makeText("Number Guess", 34, Palette::ACCENT, {0,100.f}, true);
        auto s = makeText("Guess the secret number between 1 and 100!", 18, Palette::SUBTEXT, {0,140.f}, true);
        auto g = makeText("What comes after: " + std::to_string(gameSecret) + " ?", 24, Palette::TEXT, {0, 200.f}, true);
        auto sc = makeText("Score: " + std::to_string(gameScore), 20, Palette::ACCENT2, {0, 240.f}, true);
        window.draw(h); window.draw(s); window.draw(g); window.draw(sc);
        if (gameInput) gameInput->draw(window);
        for (auto& b : gameActionBtns) { b.update(mouse); b.draw(window); }
        toast.draw(window);
    }

    void handleNumberGuessClick(sf::Vector2f mouse) {
        if (gameInput) {
            gameInput->setActive(gameInput->clicked(mouse));
            if (gameInput->clicked(mouse)) activeField = &(*gameInput);
        }
        if (gameActionBtns[0].clicked(mouse)) { // Guess
            try {
                int guess = std::stoi(gameInput->value);
                if (guess == gameSecret + 1) {
                    toast.show("Correct ! Score +1", window.getSize(), Palette::ACCENT2);
                    gameScore++;
                    triggerCorrectResponse();
                } else {
                    toast.show("Wrong! Valid was " + std::to_string(gameSecret+1), window.getSize(), Palette::DANGER, 3.f);
                    if (gameScore > 0) gameScore--;
                    triggerWrongResponse();
                }
                gameSecret = rand() % 100 + 1; // new number
                if (gameInput) { gameInput->value = ""; gameInput->displayText.setString(""); }
            } catch(...) {
                toast.show("Invalid number!", window.getSize(), Palette::DANGER);
            }
        }
        if (gameActionBtns[1].clicked(mouse)) { // Exit
            int currentScore = fm.loadProgress(loggedUser, "gamescore");
            if (currentScore < 0) currentScore = 0;
            fm.saveProgress(loggedUser, "gamescore", currentScore + gameScore);
            toast.show("Game Over! Earned " + std::to_string(gameScore), window.getSize(), Palette::ACCENT2);
            activeField = nullptr;
            screen = Screen::GAME_MENU; buildGameMenu();
        }
    }

    // ================= GAME: PICTURE QUIZ =================

    void buildPictureQuiz() {
        PictureQuizGame backend;
        int qIdx = rand() % 10;
        auto& q = backend.questions[qIdx];
        
        gameActionBtns.clear();
        float cx = window.getSize().x / 2.f;
        gameActionBtns.push_back({font, q.options[0], {cx-170,360}, {160,50}, Palette::ACCENT, {80,83,220,255}});
        gameActionBtns.push_back({font, q.options[1], {cx+10,360}, {160,50}, Palette::ACCENT, {80,83,220,255}});
        gameActionBtns.push_back({font, q.options[2], {cx-170,420}, {160,50}, Palette::ACCENT, {80,83,220,255}});
        gameActionBtns.push_back({font, q.options[3], {cx+10,420}, {160,50}, Palette::ACCENT, {80,83,220,255}});
        gameActionBtns.push_back({font, "Exit", {cx-80,480}, {160,50}, Palette::DANGER, {190,40,40,255}});
        
        gameAttempt = q.correctIndex;
        
        std::string filename = q.hint;
        std::transform(filename.begin(), filename.end(), filename.begin(), ::tolower);
        filename = "assets/images/" + filename + ".png";
        if (!gameTexture.loadFromFile(filename)) {
            gameString = "Missing: " + filename;
        } else {
            gameString = "";
            gameSprite.emplace(gameTexture);
            float sx = 150.f / gameTexture.getSize().x;
            float sy = 150.f / gameTexture.getSize().y;
            gameSprite->setScale(sf::Vector2f(sx, sy));
            gameSprite->setPosition(sf::Vector2f(cx - 75.f, 180.f));
        }
    }

    void drawPictureQuiz(sf::Vector2f mouse) {
        window.clear(Palette::BG); drawDecorCircles();
        auto h = makeText("Picture Quiz", 34, Palette::ACCENT2, {0,80.f}, true);
        auto sc = makeText("Score: " + std::to_string(gameScore), 20, Palette::TEXT, {0, 120.f}, true);
        window.draw(h); window.draw(sc);
        if (gameString != "") {
            auto pic = makeText(gameString, 24, Palette::DANGER, {0, 220.f}, true);
            window.draw(pic);
        } else if (gameSprite) {
            window.draw(*gameSprite);
        }
        for (auto& b : gameActionBtns) { b.update(mouse); b.draw(window); }
        toast.draw(window);
    }

    void handlePictureQuizClick(sf::Vector2f mouse) {
        for (int i=0; i<4; i++) {
            if (gameActionBtns[i].clicked(mouse)) {
                if (i == gameAttempt) {
                    toast.show("Correct!", window.getSize(), Palette::ACCENT2); gameScore++;
                    triggerCorrectResponse();
                } else {
                    toast.show("Wrong!", window.getSize(), Palette::DANGER); if (gameScore > 0) gameScore--;
                    triggerWrongResponse();
                }
                int currentScore = gameScore;
                buildPictureQuiz();
                gameScore = currentScore;
                break;
            }
        }
        if (gameActionBtns[4].clicked(mouse)) { // Exit
            int currentScore = fm.loadProgress(loggedUser, "gamescore");
            if (currentScore < 0) currentScore = 0;
            fm.saveProgress(loggedUser, "gamescore", currentScore + gameScore);
            toast.show("Game Over! Earned " + std::to_string(gameScore), window.getSize(), Palette::ACCENT2);
            screen = Screen::GAME_MENU; buildGameMenu();
        }
    }

    // ================= GAME: MISSING LETTER =================

    void buildMissingLetter() {
        MissingLetterPuzzle backend;
        int qIdx = rand() % 10;
        auto& q = backend.questions[qIdx];
        
        gameString = q.word;
        gameAttempt = q.correctIndex;
        gameActionBtns.clear();
        
        float cx = window.getSize().x / 2.f;
        gameActionBtns.push_back({font, q.options[0], {cx-170,320}, {160,50}, Palette::ACCENT, {80,83,220,255}});
        gameActionBtns.push_back({font, q.options[1], {cx+10,320}, {160,50}, Palette::ACCENT, {80,83,220,255}});
        gameActionBtns.push_back({font, q.options[2], {cx-170,380}, {160,50}, Palette::ACCENT, {80,83,220,255}});
        gameActionBtns.push_back({font, q.options[3], {cx+10,380}, {160,50}, Palette::ACCENT, {80,83,220,255}});
        gameActionBtns.push_back({font, "Exit", {cx-80,460}, {160,50}, Palette::DANGER, {190,40,40,255}});
    }

    void drawMissingLetter(sf::Vector2f mouse) {
        window.clear(Palette::BG); drawDecorCircles();
        auto h = makeText("Missing Letter", 34, Palette::ACCENT3, {0,100.f}, true);
        auto sc = makeText("Score: " + std::to_string(gameScore), 20, Palette::TEXT, {0, 140.f}, true);
        
        auto pzl = makeText(gameString, 48, Palette::WHITE, {0, 200.f}, true);
        window.draw(h); window.draw(sc); window.draw(pzl);
        for (auto& b : gameActionBtns) { b.update(mouse); b.draw(window); }
        toast.draw(window);
    }

    void handleMissingLetterClick(sf::Vector2f mouse) {
        for (int i=0; i<4; i++) {
            if (gameActionBtns[i].clicked(mouse)) {
                if (i == gameAttempt) {
                    toast.show("Correct!", window.getSize(), Palette::ACCENT2); gameScore++;
                    triggerCorrectResponse();
                } else {
                    toast.show("Try Again!", window.getSize(), Palette::DANGER); if (gameScore > 0) gameScore--;
                    triggerWrongResponse();
                }
                int currentScore = gameScore;
                buildMissingLetter();
                gameScore = currentScore;
                return;
            }
        }
        if (gameActionBtns[4].clicked(mouse)) { // Exit
            int currentScore = fm.loadProgress(loggedUser, "gamescore");
            if (currentScore < 0) currentScore = 0;
            fm.saveProgress(loggedUser, "gamescore", currentScore + gameScore);
            toast.show("Game Over! Earned " + std::to_string(gameScore), window.getSize(), Palette::ACCENT2);
            activeField = nullptr;
            screen = Screen::GAME_MENU; buildGameMenu();
        }
    }

    // ================= GAME: COLOR GUESS =================

    void buildColorGuess() {
        ColorGuessGame backend;
        int qIdx = rand() % 12;
        auto& q = backend.questions[qIdx];
        
        gameString = q.object;
        gameAttempt = q.correctIndex;
        gameActionBtns.clear();
        
        auto lookupColor = [&](const std::string& name) {
            for(size_t j=0; j<colorNames.size(); j++) {
                if(colorNames[j] == name) return colorVals[j];
            }
            return Palette::ACCENT;
        };

        float cx = window.getSize().x / 2.f;
        gameActionBtns.push_back({font, q.options[0], {cx-170,300}, {160,50}, lookupColor(q.options[0]), lookupColor(q.options[0])});
        gameActionBtns.push_back({font, q.options[1], {cx+10,300}, {160,50}, lookupColor(q.options[1]), lookupColor(q.options[1])});
        gameActionBtns.push_back({font, q.options[2], {cx-170,360}, {160,50}, lookupColor(q.options[2]), lookupColor(q.options[2])});
        gameActionBtns.push_back({font, q.options[3], {cx+10,360}, {160,50}, lookupColor(q.options[3]), lookupColor(q.options[3])});
        gameActionBtns.push_back({font, "Exit", {cx-80,440}, {160,50}, Palette::CARD, Palette::CARD_HOV});
        
        std::string filename = q.object;
        std::transform(filename.begin(), filename.end(), filename.begin(), ::tolower);
        filename = "assets/images/" + filename + ".png";
        gameSprite.reset();
        if (gameTexture.loadFromFile(filename)) {
            gameSprite.emplace(gameTexture);
            float sx = 100.f / gameTexture.getSize().x;
            float sy = 100.f / gameTexture.getSize().y;
            gameSprite->setScale(sf::Vector2f(sx, sy));
            gameSprite->setPosition(sf::Vector2f(cx - 50.f, 160.f));
        }
    }

    void drawColorGuess(sf::Vector2f mouse) {
        window.clear(Palette::BG); drawDecorCircles();
        auto h = makeText("What Color is " + gameString + "?", 30, Palette::TEXT, {0,80.f}, true);
        auto sc = makeText("Score: " + std::to_string(gameScore), 20, Palette::SUBTEXT, {0, 120.f}, true);
        window.draw(h); window.draw(sc);
        
        if (gameSprite) {
            window.draw(*gameSprite);
        } else {
            sf::RectangleShape box({100.f, 100.f});
            box.setPosition({window.getSize().x/2.f - 50.f, 160.f});
            box.setFillColor(Palette::CARD_HOV);
            box.setOutlineThickness(2.f); box.setOutlineColor(Palette::SUBTEXT);
            window.draw(box);
        }
        for (auto& b : gameActionBtns) { b.update(mouse); b.draw(window); }
        toast.draw(window);
    }

    void handleColorGuessClick(sf::Vector2f mouse) {
        for (int i=0; i<4; i++) {
            if (gameActionBtns[i].clicked(mouse)) {
                if (i == gameAttempt) {
                    toast.show("Correct!", window.getSize(), Palette::ACCENT2); gameScore++;
                    triggerCorrectResponse();
                } else {
                    toast.show("Try Again!", window.getSize(), Palette::DANGER); if (gameScore > 0) gameScore--;
                    triggerWrongResponse();
                }
                int currentScore = gameScore;
                buildColorGuess();
                gameScore = currentScore;
                break;
            }
        }
        if (gameActionBtns[4].clicked(mouse)) { // Exit
            int currentScore = fm.loadProgress(loggedUser, "gamescore");
            if (currentScore < 0) currentScore = 0;
            fm.saveProgress(loggedUser, "gamescore", currentScore + gameScore);
            toast.show("Game Over! Earned " + std::to_string(gameScore), window.getSize(), Palette::ACCENT2);
            screen = Screen::GAME_MENU; buildGameMenu();
        }
    }

    // ================= HELPERS / UTILITIES =================

    bool hasAnyProgress(const std::string& username) {
        std::vector<std::string> keys = {"alpha", "number", "fruit", "animal", "gamescore"};
        for (const auto& key : keys) {
            int val = fm.loadProgress(username, key);
            if (val > 0) {
                return true;
            }
        }
        return false;
    }

    sf::Text makeText(const std::string& s, unsigned sz,
                      sf::Color col, sf::Vector2f pos,
                      bool centreX = false) {
        sf::Text t(font, s, sz);
        t.setFillColor(col);
        if (centreX) {
            sf::FloatRect b = t.getLocalBounds();
            t.setOrigin({b.position.x + b.size.x / 2.f, 0.f});
            t.setPosition({window.getSize().x / 2.f, pos.y});
        } else {
            t.setPosition(pos);
        }
        return t;
    }

    void playClick() {
        sf::sleep(sf::milliseconds(150));
        if (clickSound) clickSound->play();
    }
    void playCorrect() {
        sf::sleep(sf::milliseconds(150));
        if (correctSound) correctSound->play();
    }
    void playWrong() {
        sf::sleep(sf::milliseconds(150));
        if (wrongSound) wrongSound->play();
    }

    void triggerCorrectResponse() {
        playCorrect();
    }
    void triggerWrongResponse() {
        playWrong();
    }

    void speakItem(int idx) {
        if (idx < 0 || idx >= lessonTotal) return;
        std::string cmd = "say \"[[volm 1.0]] [[pbas 90]] " + lessonItems[idx].speak + "\" &";
        system(cmd.c_str());
        lessonClock.restart();
        repeatTimer = 0.f;
    }

    void speakPrompt(std::string text) {
        std::string cmd = "say \"[[volm 1.0]] [[pbas 90]] " + text + "\" &";
        system(cmd.c_str());
    }

    void drawDecorCircles() {
        float t = splashClock.getElapsedTime().asSeconds();
        sf::CircleShape c1(160.f);
        c1.setFillColor({99,102,241,18});
        c1.setPosition({-80.f, -60.f});
        window.draw(c1);

        sf::CircleShape c2(120.f);
        c2.setFillColor({16,185,129,18});
        c2.setPosition({(float)window.getSize().x-100.f,
                        (float)window.getSize().y-100.f});
        window.draw(c2);

        float wobble = 4.f * std::sin(t * 1.5f);
        sf::CircleShape c3(60.f + wobble);
        c3.setFillColor({245,158,11,14});
        c3.setPosition({(float)window.getSize().x - 80.f, 20.f});
        window.draw(c3);
    }

    void drawFormCard(float topY, float height) {
        float cx = window.getSize().x / 2.f;
        sf::RectangleShape card({420.f, height});
        card.setFillColor(Palette::CARD);
        card.setPosition({cx-210.f, topY});
        window.draw(card);
    }
};

#endif // UI_H